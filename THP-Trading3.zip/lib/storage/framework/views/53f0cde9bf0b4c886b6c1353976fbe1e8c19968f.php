<?xml version="1.0" encoding="UTF-8"?>
<urlset
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->

	<url>
	  <loc><?php echo e(asset('/')); ?></loc>
	  <lastmod><?php echo e(date('Y-m-d')); ?>T<?php echo e(date('H:i:s')); ?>+00:00</lastmod>
	  <priority>1.00</priority>
	</url>

	<!-- Page -->
	<?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<url>
		  <loc><?php echo e(asset('/'.$pg->page_slug.'.html')); ?></loc>
		  <lastmod><?php echo e(date('Y-m-d')); ?>T<?php echo e(date('H:i:s')); ?>+00:00</lastmod>
		  <priority>0.8</priority>
		</url>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<!-- Cate -->
	<?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<url>
		  <loc><?php echo e(asset('/'.$ct->cate_slug)); ?></loc>
		  <lastmod><?php echo e(date('Y-m-d')); ?>T<?php echo e(date('H:i:s')); ?>+00:00</lastmod>
		  <priority>0.8</priority>
		</url>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	<!-- Post -->
	<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<url>
			<?php
				foreach($cate as $ct2){
					if($ct2->cate_id == $pt->post_cate_id){
						$cate_slug = $ct2->cate_slug;
					}
				}
			?>
			<loc><?php echo e(asset('/'.$cate_slug.'/'.$pt->post_slug.'-'.$pt->post_id.'.html')); ?></loc>
			<lastmod><?php echo e(date('Y-m-d')); ?>T<?php echo e(date('H:i:s')); ?>+00:00</lastmod>
			<priority>0.8</priority>
		</url>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</urlset><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/site/site-map.blade.php ENDPATH**/ ?>