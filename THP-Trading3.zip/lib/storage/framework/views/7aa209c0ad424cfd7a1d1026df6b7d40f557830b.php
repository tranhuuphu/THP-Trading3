
<?php $__env->startSection('title', 'Danh sách sản phẩm'); ?>



<?php $__env->startSection('main'); ?>


	<div class="col-sm-12 col-lg-12 main" style="margin-top: 40px;">
		<div class="row">
			<div class="col-lg-12">
				<ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(asset('admin/')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(asset('admin/post')); ?>"><strong>Bài Viết</strong></a></li>
                </ol>
				<div class="card">
				  <div class="card-header">
				    <a href="<?php echo e(asset('admin/post/add')); ?>" class="btn btn-warning"><i class="fas fa-plus"></i> Thêm bài viết</a>
				  </div>
				</div>
                
                <?php echo $__env->make('notice.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				


				<div class="card mb-4" style="margin-top: 20px;">
                    <div class="card-header bg-dark text-white"><i class="fas fa-table mr-1"></i> <strong>Danh Sách Bài Viết</strong></div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên Bài Viết</th>
                                        <th>Menu</th>
                                        <th>Nổi Bật</th>
                                        <th>Ảnh</th>
                                        <th>Option</th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên Bài Viết</th>
                                        <th>Menu</th>
                                        <th>Nổi Bật</th>
                                        <th>Ảnh</th>
                                        <th>Option</th>
                                    </tr>
                                </tfoot>
                                <tbody>
									<?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($p->post_id); ?></td>
											<td><?php echo e($p->post_title); ?></td>
											<td><?php echo e($p->cate_name); ?></td>
											<td><?php echo e($p->post_status); ?></td>
											<td>
												<img width="200px" src="<?php echo e(asset('public/upload/post/'.$p->post_image)); ?>" class="thumbnail">
											</td>
											<td>
												<a href="<?php echo e(asset('admin/post/edit/'.$p->post_id)); ?>" class="btn btn-warning"><i class="fa fa-pencil" aria-hidden="true"></i> Sửa</a>
												<a href="<?php echo e(asset('admin/post/delete/'.$p->post_id)); ?>" onclick="return confirm('Bạn có chắc chắn muốn xóa?')" class="btn btn-danger"><i class="fa fa-trash" aria-hidden="true"></i> Xóa</a>
											</td>
                                        </tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>



			</div>
		</div><!--/.row-->


		

	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/admin/post/post.blade.php ENDPATH**/ ?>