

<?php $__env->startSection('content'); ?>


	
	<div class="container">
		<nav aria-label="breadcrumb" style="margin: 30px 0;">
		  <ol class="breadcrumb" style="border-radius: 0; background: #54b8ff">
		    <li class="breadcrumb-item"><a href="<?php echo e(asset('')); ?>">Home</a></li>
		    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(asset('/'.$page_result->page_slug)); ?>" title="<?php echo e($page_result->page_title); ?>" style="text-transform: capitalize;"><?php echo e($page_result->page_title); ?></a></li>
		  </ol>
		</nav>
	</div>
	
	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-8">
					<?php echo $page_result->page_content; ?>

				</div>
				
				<!-- aside -->
				<div class="col-md-4">
					<!-- ad -->
					<div class="aside-widget text-center">
						<a href="#" style="display: inline-block;margin: auto;">
							<img class="img-responsive" src="./img/ad-1.jpg" alt="">
						</a>
					</div>
					<!-- /ad -->
				</div>
				<!-- /aside -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?><?php echo e($page_result->page_title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($page_result->meta_desc); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e($page_result->meta_key); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('image'); ?><?php echo e(asset('public/upload/page/'.$page_result->page_image)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('url'); ?><?php echo e(asset('/'.$page_result->page_slug.'.html')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('created_at'); ?><?php echo e($page_result->created_at); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('updated_at'); ?><?php echo e($page_result->updated_at); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/site/page.blade.php ENDPATH**/ ?>