


<?php $__env->startSection('main'); ?>
<div class="container-fluid">
  <div class="row">
      <div class="col-lg-12" style="margin-top: 40px;">
          <ol class="breadcrumb mb-4">
              <li class="breadcrumb-item active"><a href="<?php echo e(asset('admin/')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item"><strong><a href="<?php echo e(asset('admin/roles')); ?>">Roles Management</a></strong></li>
              <li class="breadcrumb-item"><strong>Create New Roles Management</strong></li>
          </ol>

      </div>
  </div><!--/.row-->
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Create New Role</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('roles.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Back</a>
            </div>
        </div>
    </div>
    <hr>


    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <?php echo Form::open(array('route' => 'roles.store','method'=>'POST')); ?>

    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Vai Trò:</strong>
                <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>

            </div>
        </div>
        <hr>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Gán Quyền:</strong>
                <table class="table mt-3">
                  <thead>
                    
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                          <td class="font-weight-bold"><?php echo e(Form::checkbox('permission[]', $value->id, false, array('class' => 'name'))); ?>

                        <?php echo e($value->name); ?></td>
                        </tr>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  </tbody>
                </table>

            </div>
        </div>
        <hr>
        <div class="col-xs-12 col-sm-12 col-md-12 mb-5">
            <button type="submit" class="btn btn-primary">Submit</button>
            <button type="submit" class="btn btn-warning ml-20"><a href="<?php echo e(route('roles.index')); ?>">Cancel<a></button>
        </div>
    </div>
    <?php echo Form::close(); ?>



</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading3\lib\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>