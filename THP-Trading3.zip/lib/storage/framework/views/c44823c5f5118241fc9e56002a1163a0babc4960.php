

<?php $__env->startSection('content'); ?>
	
<div class="section">
	<!-- container -->
	<div class="container">
		<!-- row -->
		<div class="row">
			<div class="col-md-8">
				
				<!-- post widget -->
				<div class="aside-widget">
					<div class="section-title">
						<h2>Search Result From <label style="color: red">Google</label> key: <label style="color: #fc9d03"><?php echo e($show_result); ?></label></h2>
					</div>
					<div class="gcse-search"></div>
					

					

					
				</div>
				<!-- /post widget -->

				
			</div>
			<div class="col-md-4">
				<!-- ad -->
				<div class="aside-widget text-center">
					<a href="javascript:void(0)" style="display: inline-block;margin: auto;">
						<img class="img-responsive" src="./img/ad-1.jpg" alt="">
					</a>
				</div>
				<!-- /ad -->
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?><?php echo e('Tìm kiếm từ khóa: '.$show_result); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($show_result); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e($show_result); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/site/search.blade.php ENDPATH**/ ?>