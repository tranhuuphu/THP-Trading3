
        

<!-- Header -->
<header>
	<!-- Header desktop -->
	<div class="container-menu-desktop">
		<div class="topbar">
			<div class="content-topbar container h-100">
				<div class="left-topbar">
					
					<?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<a href="<?php echo e(asset('/').$pg->page_slug.'.html'); ?>" title="<?php echo e($pg->page_title); ?>" class="left-topbar-item" style="text-transform: capitalize;">
							<?php echo e($pg->page_title); ?>

						</a>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>

				<div class="right-topbar flex-wr-s-c" style="display: flex !important;">
					<div style="padding-top: 6px; padding-right: 10px;">
						<a href="javascript:void(0)">
							<span class="fab fa-facebook-f"></span>
						</a>

						
					</div>

					<style type="text/css">

						
						
					</style>

					<!-- Actual search box with the icon on the right -->
					<form class="form-group has-search-right" method="get" action="<?php echo e(asset('search/')); ?>" style="border-radius: 0px;">
						<button type="submit" class="form-control-feedback"><span class="fa fa-search"></span></button>
						<input type="text" required="" name="q" placeholder="Search" type="text" class="form-control">
					</form>

					

				</div>
			</div>
		</div>

		<!-- Header Mobile -->
		<div class="wrap-header-mobile">
			<!-- Logo moblie -->		
			<div class="logo-mobile">
				<a href="<?php echo e(asset('')); ?>" title="Logo"><img src="<?php echo e(asset('public/upload/page/'.$page_favicon->page_image)); ?>" alt="<?php echo e($page_favicon->meta_key); ?>"></a>
			</div>

			<!-- Button show menu -->
			<div class="btn-show-menu-mobile hamburger hamburger--squeeze m-r--8">
				<span class="hamburger-box">
					<span class="hamburger-inner"></span>
				</span>
			</div>
		</div>

		<!-- Menu Mobile -->
		<div class="menu-mobile">
			<ul class="topbar-mobile">
				
				


				<li class="left-topbar">

					<?php $__currentLoopData = $page; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="<?php echo e(asset('/').$p->page_slug.'.html'); ?>" title="<?php echo e($p->page_title); ?>" style="text-transform: capitalize;" class="left-topbar-item" style="text-transform: capitalize;">
						<?php echo e($p->page_title); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				

				</li>

				<li class="right-topbar flex-wr-s-c">
					<a href="javascript:void(0)">
						<span class="fab fa-facebook-f"></span>
					</a>

					<!-- partial:index.partial.html -->
					<div class="main-search">
					  
					  <!-- Actual search box with the icon on the right -->
					  <form class="form-group has-search-right" method="get" action="<?php echo e(asset('search/')); ?>" style="border-radius: 0px;">
					    <button type="submit" class="form-control-feedback"><span class="fa fa-search"></span></button>
					    <input type="text" name="q" placeholder="Search" type="text" class="form-control">
					  </form>
					  
					</div>
					<!-- partial -->
				</li>
			</ul>

			<ul class="main-menu-m">
				<li>
					<a href="<?php echo e(asset('')); ?>" title="Trang Chủ">Home</a>
				</li>
				
				<?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li>
						<a href="<?php echo e(asset('/'.$c->cate_slug)); ?>" title="<?php echo e($c->cate_name); ?>" style="text-transform: capitalize;"><?php echo e($c->cate_name); ?></a>
					</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




			</ul>
		</div>
		
		<!--  Logo desktop -->
		<div class="wrap-logo container">
			<!-- Logo desktop -->		
			<div class="logo">
				<a href="<?php echo e(asset('')); ?>"><img src="<?php echo e(asset('public/upload/page/'.$page_favicon->page_image)); ?>" height="60px" alt="<?php echo e($page_favicon->meta_key); ?>"></a>
			</div>	

			<!-- Banner -->
			<div class="banner-header" style="background: #eee">
				<a href="javascript:void(0)"></a>
			</div>
		</div>	
		
		<!-- Menu desktop  -->
		<div class="wrap-main-nav">
			<div class="main-nav">
				<!-- Menu desktop -->
				<nav class="menu-desktop">
					<a class="logo-stick" href="<?php echo e(asset('')); ?>">
						<img src="<?php echo e(asset('public/upload/page/'.$page_favicon->page_image)); ?>" alt="<?php echo e($page_favicon->meta_key); ?>">
					</a>

					<ul class="main-menu">
						<li class="main-menu-active">
							<a href="<?php echo e(asset('/')); ?>">Home</a>
						</li>
						<li class="main-menu">
							<a href="#" title="#" style="text-transform: capitalize;">#</a>
						</li>	
						<?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="main-menu2">
								<a href="<?php echo e(asset('/'.$c->cate_slug)); ?>" title="<?php echo e($c->cate_name); ?>" style="text-transform: capitalize;"><?php echo e($c->cate_name); ?></a>
								<ul class="sub-menu">
									<li><a href="index.html">Homepage v1</a></li>
									<li><a href="home-02.html">Homepage v2</a></li>
									<li><a href="home-03.html">Homepage v3</a></li>
								</ul>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						

					</ul>
				</nav>
			</div>
		</div>	
	</div>
</header>

<!-- Header --><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/site/nav.blade.php ENDPATH**/ ?>