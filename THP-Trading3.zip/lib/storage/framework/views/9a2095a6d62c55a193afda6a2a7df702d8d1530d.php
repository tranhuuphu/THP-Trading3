

<?php $__env->startSection('content'); ?>


	<?php
		$post_1 = $post_cate->shift(1);
		$post_2 = $post_cate->slice(0, 2);
		$post_3 = $post_cate->slice(2,10);
	?>
	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container" >
			<!-- row -->
			<div class="row">
				<div class="col-md-8" >
					<div class="row" >
						<!-- post -->
						<div class="col-md-12 mt-3">
							<div class="post post-thumb">
								<a class="post-img img-carbox3" href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$post_1->post_slug.'-'.$post_1->post_id.'.html')); ?>" title="<?php echo e($post_1->post_title); ?>">
									<img src="<?php echo e(asset('public/upload/post/'.$post_1->post_image)); ?>" alt="<?php echo e($post_1->post_title); ?>">
								</a>
								<div class="post-body">
									<div class="post-meta">
										
										<span class="post-date"><?php echo substr($post_1->created_at, 0, 7) ?></span>
									</div>
									<h3 class="post-title"><a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$post_1->post_slug.'-'.$post_1->post_id.'.html')); ?>" title="<?php echo e($post_1->post_title); ?>"><?php echo e($post_1->post_title); ?></a></h3>
								</div>
							</div>
						</div>
						<!-- /post -->


									
						<!-- post -->
						<?php $__currentLoopData = $post_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-6" >
								<div class="post">
									<a class="post-img img-carbox6" href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_2->post_slug.'-'.$p_2->post_id.'.html')); ?>" title="<?php echo e($p_2->post_title); ?>"><img src="<?php echo e(asset('public/upload/post/'.$p_2->post_image)); ?>" alt="<?php echo e($p_2->post_title); ?>"></a>
									<div class="post-body">
										<div class="post-meta">
											
											<span class="post-date"><?php echo substr($p_2->created_at, 0, 7) ?></span>
										</div>
										<h3 class="post-title"><a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_2->post_slug.'-'.$p_2->post_id.'.html')); ?>" title="<?php echo e($p_2->post_title); ?>"><?php echo e($p_2->post_title); ?></a></h3>
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<!-- /post -->

						<hr style="border-bottom: 2px solid #000">
						
						<div class="clearfix visible-md visible-lg" ></div>
						
						<!-- ad -->
						<div class="col-md-12 visible-md visible-sm visible-xs" style="height: 0px !important">
							<div class="section-row">
								<a href="javascript:void(0)">
									<img class="img-responsive center-block" src="./img/ad-2.jpg" alt="" width="100%">
								</a>
							</div>
						</div>
						<!-- ad -->
						
						<style>
							.post-singer {
							  overflow: auto;
							  padding-bottom: 25px;
							  padding-left: 15px;
							  padding-right: 15px;
							  margin-bottom: 10px;
							  border-bottom: 1px dashed #b9bbbd;
							}
							.post-singer a img:hover{
								opacity: 0.85;
								transition: 0.3s;
							}

							.img2 {
							  float: left;
							  padding: 0 15px 0 0;
							  margin-top: 5px;
							  width: 30%;
							}
							.intro{
								font-family: 'Nunito' !important;
								font-size: 17px;
								text-align: justify;
							}
							.title-2{
								padding: 5px 15px;
								font-family: 'Nunito Sans' !important;
								font-size: 20px;
								font-weight: bold;
								color: #434343;
							}

							@media  only screen and (max-width: 991px) {
							    .img2 {
								  width: 40%;
								}
								.intro{
									font-size: 15px;
								}
								.title-2{
									font-size: 18px;
								}
							}
						</style>
						<!-- post 3 -->
						<?php $__currentLoopData = $post_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-12">
								
								<div style="background: #fff">
									<div class="title-2">
										<a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_3->post_slug.'-'.$p_3->post_id.'.html')); ?>" title="<?php echo e($p_3->post_title); ?>"><?php echo e($p_3->post_title); ?></a>
									</div>
									<div class="post-singer">
									  <a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_3->post_slug.'-'.$p_3->post_id.'.html')); ?>" title="<?php echo e($p_3->post_title); ?>">
									  	<img class="img2" src="<?php echo e(asset('public/upload/post/'.$p_3->post_image)); ?>" alt="<?php echo e($p_3->post_title); ?>" height="auto">
									  </a>
									  <div class="intro"><?php echo e($p_3->post_intro); ?></div>
									</div>
								</div>
									
								

								
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<!-- /post -->
						

						
						<div class="col-md-12">
							<div class="section-row">
								<?php echo e($post_cate->links()); ?>

							</div>
						</div>
					</div>
				</div>
				
				<div class="col-md-4">
					<!-- ad -->
					<div class="aside-widget text-center mt-3" style="background: #ffffff">
						<a href="javascript:void(0)" style="display: inline-block;margin: auto;">
							Adv
							<img class="img-responsive" src="./img/ad-1.jpg" alt="" width="100%">
						</a>
					</div>
					<!-- /ad -->
					
					<!-- post widget -->
					<div class="aside-widget">
						<div class="section-title">
							<h2>Đọc Nhiều</h2>
						</div>
						<?php $__currentLoopData = $most_read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($c->cate_id == $mr->post_cate_id): ?>
									<div class="post post-widget">
										<a class="post-img img-carbox4" href="blog-post.html" style="margin-top: 7px;"><img src="<?php echo e(asset('public/upload/post/'.$mr->post_image)); ?>" alt="<?php echo e($mr->post_title); ?>"></a>
										<div class="post-body">
											<h3 class="post-title"><a href="<?php echo e(asset('/'.$c->cate_slug.'/'.$mr->post_slug.'-'.$mr->post_id.'.html')); ?>" title="<?php echo e($mr->post_title); ?>"><?php echo e($mr->post_title); ?></a></h3>
											<p><?php echo e($mr->post_intro); ?></p>
										</div>
									</div>
								<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<!-- /post widget -->
					
					<!-- catagories -->
					<div class="aside-widget">
						<div class="section-title">
							<h2>Chuyên Mục</h2>
						</div>
						<div class="category-widget">
							<ul>
								<?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(asset('/'.$c->cate_slug)); ?>" title="<?php echo e($c->cate_name); ?>" class="cat-1"><?php echo e($c->cate_name); ?><span>
										<?php
											echo $count = DB::table('post')->where('post_cate_id', $c->cate_id)->count();
										?>
									</span></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
					<!-- /catagories -->
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->



<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?><?php echo e($cate_detail->cate_name); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($cate_detail->meta_desc); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e($cate_detail->meta_key); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('image'); ?><?php echo e(asset('public/upload/page/'.$page_favicon->page_image)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('url'); ?><?php echo e(asset('/'.$cate_detail->cate_slug)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('created_at'); ?><?php echo e($cate_detail->created_at); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('updated_at'); ?><?php echo e($cate_detail->updated_at); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/site/post.blade.php ENDPATH**/ ?>