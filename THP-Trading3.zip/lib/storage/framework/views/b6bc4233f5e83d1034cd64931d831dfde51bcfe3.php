

<?php $__env->startSection('content'); ?>


	<?php

		$post_2 = $post_cate->slice(0, 2);
		$post_3 = $post_cate->slice(2,10);
	?>


	<!-- Popular News Section Begin -->
    <section class="popular-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">

                    <div class="row">
                    	<?php $__currentLoopData = $post_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        	<div class="col-md-6">
                        	
                        	
	                            <div class="news-item popular-item set-bg" data-setbg="<?php echo e(asset('public/upload/post/'.$p_2->post_image)); ?>">
	                                
	                                <div class="ni-text">
	                                    <h5><a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_2->post_slug.'-'.$p_2->post_id.'.html')); ?>" title="<?php echo e($p_2->post_title); ?>"><?php echo e($p_2->post_title); ?></a></h5>
	                                    
	                                </div>
	                            </div>
                            	<hr>
                        	</div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <div class="col-md-12">

                        	<?php $__currentLoopData = $post_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                        	<div class="news-item">
	                                <div class="ni-pic ni-pic2">
	                                    <img src="<?php echo e(asset('public/upload/post/'.$p_3->post_image)); ?>" alt="$p_3->post_title">
	                                </div>
	                                <div class="ni-text">
	                                    <h5><a href="<?php echo e(asset('/'.$cate_detail->cate_slug.'/'.$p_3->post_slug.'-'.$p_3->post_id.'.html')); ?>" title="<?php echo e($p_3->post_title); ?>"><?php echo e($p_3->post_title); ?></a></h5>

	                                    <ul class="widget">
                                            <li><?php echo e($p_3->post_intro); ?></li>
                                        </ul>
	                                </div>
	                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <nav aria-label="Page navigation example">
								<ul class="pagination">
									<?php echo $post_cate->links(); ?>
								</ul>
							</nav>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="section-title">
                        
                    </div>
                    
                    <style type="text/css">
                    	.post h5{
                    		font-weight: bold;
                    		padding-bottom: 15px;
                    	}
                    </style>
                    <div class="section-title">
						<h2>Đọc Nhiều</h2>
					</div>
					<?php $__currentLoopData = $most_read; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="post post-widget">
							<h5 class="post-title"><a href="<?php echo e(asset('/'.$mr->cate_slug.'/'.$mr->post_slug.'-'.$mr->post_id.'.html')); ?>" title="<?php echo e($mr->post_title); ?>"><?php echo e($mr->post_title); ?></a></h5>
							<div class="media">
								<img src="<?php echo e(asset('public/upload/post/'.$mr->post_image)); ?>" width="40%" class="mr-3" alt="<?php echo e($mr->post_title); ?>">
								<div class="media-body">
									
									<p><?php echo e($mr->post_intro); ?></p>
								</div>
							</div>

						</div>
						<hr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
    <!-- Popular News Section End -->




<?php $__env->stopSection(); ?>



<?php $__env->startSection('title'); ?><?php echo e($cate_detail->cate_name); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($cate_detail->meta_desc); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e($cate_detail->meta_key); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('image'); ?><?php echo e(asset('public/upload/page/'.$page_favicon->page_image)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('url'); ?><?php echo e(asset('/'.$cate_detail->cate_slug)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('created_at'); ?><?php echo e($cate_detail->created_at); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('updated_at'); ?><?php echo e($cate_detail->updated_at); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading3\lib\resources\views/site/post.blade.php ENDPATH**/ ?>