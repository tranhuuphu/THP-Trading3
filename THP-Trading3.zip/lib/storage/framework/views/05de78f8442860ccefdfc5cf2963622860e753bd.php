<?php $__env->startSection('title', 'Trang Sửa Danh Mục'); ?>
<?php $__env->startSection('main'); ?>	
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Danh mục sản phẩm</h1>
			</div>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-xs-12 col-md-5 col-lg-5">
					<div class="panel panel-primary">
						<div class="panel-heading">
							Sửa danh mục
						</div>
						<div class="panel-body">

							<?php echo $__env->make('error.note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							<form method="post">
								<div class="form-group">
									<label>Tên danh mục:</label>
	    							<input type="text" name="name" class="form-control" placeholder="Tên danh mục..." value="<?php echo e($cate->cate_name); ?>">
								</div>

								<div class="form-group">
									<label>Meta Key:</label>
									<br>
									<textarea name="meta_key" class="form-control"><?php echo e($cate->meta_key); ?></textarea>
								</div>

								<div class="form-group">
									<label>Meta Desc:</label>
									<br>
									<textarea name="meta_desc" class="form-control"><?php echo e($cate->meta_desc); ?></textarea>
								</div>

								<div class="form-group">
									<input class="form-contro btn btn-primary" type="submit" name="submit" value="Edit Cate">
									
								</div>
								<div class="form-group">
									<a href="<?php echo e(asset('admin/cate')); ?>" class="form-control btn btn-danger">Hủy</a>
								</div>
								<?php echo e(csrf_field()); ?>

							</form>
						</div>
					</div>
			</div>
		</div><!--/.row-->
	</div>	<!--/.main-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/admin/edit_cate.blade.php ENDPATH**/ ?>