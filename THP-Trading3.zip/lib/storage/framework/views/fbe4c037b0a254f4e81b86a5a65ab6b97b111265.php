

<?php $__env->startSection('content'); ?>

<!-- section -->
<div class="section" style="margin-top: 40px;">
	<!-- container -->
	<div class="container">
		<!-- row -->
		<div class="row">
			<div class="col-md-8">
				<h1 style="text-align: justify;">Bạn đã nhập từ khóa không hợp lệ</h1>

				<hr>
				<h2>Kết quả trình tìm kiếm của <label style="color: red">Google</label></h2>
				<hr>
				<script async src="https://cse.google.com/cse.js?cx=018266326217034628598:uchmus2ba3r"></script>
				
				<div class="gcse-searchresults-only"></div>
			</div>
			<!-- aside -->
			<div class="col-md-4">
				<!-- ad -->
				<div class="aside-widget text-center">
					<a href="#" style="display: inline-block;margin: auto;">
						<img class="img-responsive" src="./img/ad-1.jpg" alt="">
					</a>
				</div>
				<!-- /ad -->

				
			</div>
			<!-- /aside -->
		</div>
		<!-- /row -->
		<hr>
	</div>
	<!-- /container -->
</div>
<!-- /section -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?><?php echo e("Tìm kiếm không tồn tại"); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e("Tìm kiếm không tồn tại"); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e("Tìm kiếm không tồn tại"); ?><?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/notice/401.blade.php ENDPATH**/ ?>