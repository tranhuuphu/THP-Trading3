<?php if(Session::has('error')): ?>
<p class="alert alert-danger"><?php echo e(Session::get('error')); ?></p>
<?php endif; ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/error/note.blade.php ENDPATH**/ ?>