

<?php $__env->startSection('content'); ?>




    <!-- Hero Section End -->


    <!-- Hero Section Begin array_shift -->
    <?php
        $feat_1 = array_shift($featured);
        $feat_2 = array_slice($featured, 0, 2);

        $feat_3 = array_pop($featured);

    ?>

    <section class="hero">
        <div class="hero__slider owl-carousel2">
            <div class="hero__item">
                <div class="container" >
                    <div class="row" style="padding: 0 10px;">
                        <div class="col-lg-6 p-0">
                            <div class="hero__inside__item hero__inside__item--wide set-bg"
                                data-setbg="public/upload/post/<?php echo e($feat_1->post_image); ?>" aria-label="<?php echo e($feat_1->post_title); ?>">
                                <div class="hero__inside__item__text">

                                    <div class="hero__inside__item--text">

                                        <a href="<?php echo e(asset($feat_1->cate_slug.'/'.$feat_1->post_slug.'-'.$feat_1->post_id.'.html')); ?>" title="<?php echo e($feat_1->post_title); ?>"><h4><?php echo e($feat_1->post_title); ?></h4></a>
                                        <ul class="widget">
                                            <li><?php echo e($feat_1->post_intro); ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 p-0">
                            <?php $__currentLoopData = $feat_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="hero__inside__item hero__inside__item--small set-bg"
                                    data-setbg="public/upload/post/<?php echo e($f2->post_image); ?>" aria-label="<?php echo e($feat_1->post_title); ?>">
                                    <div class="hero__inside__item__text">
                                        
                                        <div class="hero__inside__item--text">
                                            
                                            <a href="<?php echo e(asset($f2->cate_slug.'/'.$f2->post_slug.'-'.$f2->post_id.'.html')); ?>" title="<?php echo e($f2->post_title); ?>"><h5><?php echo e($f2->post_title); ?></h5></a>
                                            <ul class="widget">
                                                <li><?php echo e($f2->post_intro); ?></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                        <div class="col-lg-3 col-md-6  p-0">
                            <div class="hero__inside__item set-bg" data-setbg="public/upload/post/<?php echo e($feat_3->post_image); ?>" aria-label="<?php echo e($feat_3->post_title); ?>">
                                <div class="hero__inside__item__text">

                                    <div class="hero__inside__item--text">

                                        <a href="<?php echo e(asset($feat_3->cate_slug.'/'.$feat_3->post_slug.'-'.$feat_3->post_id.'.html')); ?>" title="<?php echo e($feat_3->post_title); ?>"><h5><?php echo e($feat_3->post_title); ?></h5></a>


                                        <ul class="widget">
                                            <li><?php echo e($feat_3->post_intro); ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!-- Hero Section End -->
    <style type="text/css">
        .heading {
          line-height: 1.5;
          margin: 0;
          padding: 0;
          font-size: 20px;
          font-weight: 300;
        }
        .media-body p{
            padding: 1rem 0;
            line-height: 1.5em;
        }

    </style>
    
    <section class="section bg-light" style="background-color: #f8f9fa; padding: 7em 0; margin-top: 50px;">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><i class="fa fa-bell-o fa-3x" aria-hidden="true"></i></div>
              <div class="media-body">
                <h3 class="heading font-weight-bold">Modern Design</h3>
                
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div>  

          </div>
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><i class="fa fa-leaf fa-3x" aria-hidden="true"></i></div>
              <div class="media-body">
                <h3 class="heading font-weight-bold">Build With Love</h3>
                
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div> 

          </div>
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><i class="fa fa-bolt fa-3x" aria-hidden="true"></i></div>
              <div class="media-body">
                <h3 class="heading font-weight-bold">Fast Loading</h3>
                
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div> 

          </div>
        </div>
      </div>
    </section>



    <!-- Soccer Section Recent Begin -->
    <section class="soccer-section">
        <div class="container">
            <div class="row" style="padding: 0 10px;">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h3>Bài Viết <span>Gần Đây</span></h3>
                    </div>
                </div>
            </div>
            <div class="row" style="padding: 0 10px;">
                <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-sm-6 p-0">
                    <div class="soccer-item set-bg" data-setbg="<?php echo e(asset('/public/upload/post/'.$ft->post_image)); ?>" alt = "<?php echo e($ft->post_title); ?>">
                        <?php $__currentLoopData = $cate3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($ct->cate_id == $ft->post_cate_id): ?>
                                <div class="si-tag"><?php echo e($ct->cate_name); ?></div>
                                <div class="si-text">
                                    <h5><a href="<?php echo e(asset('/'.$ct->cate_slug.'/'.$ft->post_slug.'-'.$ft->post_id.'.html')); ?>" title="<?php echo e($ft->post_title); ?>"><?php echo e($ft->post_title); ?></a></h5>
                                    <ul>
                                        
                                        
                                    </ul>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
    <!-- Soccer Section End -->

    <!-- Latest Section Begin -->
    <section class="latest-section">

        <div class="container">
            
            <style type="text/css">
                .nav .active, ul, li, a, .nav-item{
                    border-radius: none !important;
                }
                .nav ul li:hover{
                    background: #f8f8f8;
                }
                .ni-pic3{
                    width: 150px;
                    overflow: hidden;
                    border: 1px solid #f1f1f1;
                }
                .ni-pic3 img{
                    width: 100%;
                    height: 100%;
                    object-fit: contain;
                }

            </style>
            <div class="row">
                        
                <div class="col-lg-8">
                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $id = $ct->cate_id;
                        $sub_test = DB::table('cate2')->where('parent_cate_id', $id)->first();
                        $sub = DB::table('cate2')->where('parent_cate_id', $id)->get();
                        if($sub_test != null){
                            foreach($sub as $s){
                                $sub_cate_id[] = $s->cate_id;
                            }

                            $data_cate = DB::table('cate2')->join('post2','cate2.cate_id','=','post2.post_cate_id')->whereIn('post_cate_id', $sub_cate_id)->take(5)->get();

                        }else{
                            
                            $data_cate = DB::table('cate2')->join('post2','cate2.cate_id','=','post2.post_cate_id')->where('post_cate_id', $id)->take(5)->get();
                        }

                        $data_cate_i = $data_cate->shift();
                        $data_cate_ii = $data_cate->all();
                    ?>
                    <ul class='nav nav-pills <?php if(isset($data_cate_i)): ?> section-title <?php endif; ?>'>
                        <?php if(isset($data_cate_i)): ?>
                          <li class="nav-item" style="margin-right: 40px;">
                            <a class="nav-link active" href="<?php echo e(asset('/'.$ct->cate_slug)); ?>"><?php echo e($ct->cate_name); ?></a>
                          </li>
                        <?php endif; ?>
                        <?php $__currentLoopData = $cate2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($ct2->parent_cate_id == $ct->cate_id): ?>
                                <li class="nav-item" style="background: #f7f7f7"><a class="nav-link" href="<?php echo e(asset('/'.$ct2->cate_slug)); ?>"><?php echo e($ct2->cate_name); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <div class="row">
                        <?php if($data_cate_i != null): ?>
                            <div class="col-md-6">
                                <div class="news-item left-news">
                                    <div class="ni-pic set-bg" data-setbg="<?php echo e(asset('public/upload/post/'.$data_cate_i->post_image)); ?>" alt = '<?php echo e($data_cate_i->post_title); ?>'>
                                        
                                    </div>
                                    <div class="ni-text">
                                        <h4><a href="<?php echo e(asset('/'.$data_cate_i->cate_slug.'/'.$data_cate_i->post_slug.'-'.$data_cate_i->post_id.'.html')); ?>" title="<?php echo e($data_cate_i->post_title); ?>"><?php echo e($data_cate_i->post_title); ?></a></h4>
                                        
                                        <p><?php echo e($data_cate_i->post_intro); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <style type="text/css">
                            .intro {
                              -webkit-line-clamp: 3;
                              -webkit-box-orient: vertical;
                              overflow: hidden;
                              display: -webkit-box;
                              text-align: justify;
                            }
                        </style>
                        <?php if($data_cate_i != null): ?>
                            <div class="col-md-6">
                                <?php $__currentLoopData = $data_cate_ii; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d_ii): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="news-item">
                                        <div class="ni-pic ni-pic3">
                                            <img src="<?php echo e(asset('public/upload/post/'.$d_ii->post_image)); ?>" alt="<?php echo e($d_ii->post_title); ?>">
                                        </div>
                                        <div class="ni-text">
                                            <h5><a href="<?php echo e(asset('/'.$d_ii->cate_slug.'/'.$d_ii->post_slug.'-'.$d_ii->post_id.'.html')); ?>" title="<?php echo e($d_ii->post_title); ?>"><?php echo e($d_ii->post_title); ?></a></h5>
                                            <ul>
                                                
                                                <p class="intro"><?php echo e($d_ii->post_intro); ?></p>
                                            </ul>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                <div class="col-lg-4">
                    <div class="section-title">
                        <h3>Follow <span>Us</span></h3>
                    </div>
                    <div class="follow-links">
                        <ul>
                            <li class="facebook">
                                <i class="fa fa-facebook"></i>
                                <div class="fl-name">Facebook</div>
                                
                            </li>
                            <li class="twitter">
                                <i class="fa fa-twitter"></i>
                                <div class="fl-name">Twitter</div>
                                
                            </li>
                            <li class="google">
                                <i class="fa fa-google"></i>
                                <div class="fl-name">Google</div>
                                
                            </li>
                        </ul>
                    </div>

                    <div class="section-title">
                        <h3>Contact <span>Us</span></h3>
                    </div>
                    <img class="img-responsive" src="<?php echo e(asset('public/upload/carousel/'.$contact->carousel_image)); ?>" alt="<?php echo e($contact->carousel_title); ?>" width="100%">
                    <hr>
                    <div class="section-title mt-3">
                        <h3>Event <span></span></h3>
                    </div>
                    <img class="img-responsive" src="<?php echo e(asset('public/upload/carousel/'.$right_bar->carousel_image)); ?>" alt="<?php echo e($right_bar->carousel_title); ?>" width="100%">

                    <div class="aside-widget text-center">
                        <a href="#" style="display: inline-block;margin: auto;">
                            <img class="img-responsive" src="./public/upload/img/ad-1.jpg" alt="" width="100%">
                        </a>
                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!-- Latest Section End -->






<?php $__env->stopSection(); ?>


<?php $__env->startSection('title'); ?><?php echo e($home_meta->page_title); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?><?php echo e($home_meta->meta_desc); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('keywords'); ?><?php echo e($home_meta->meta_key); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('image'); ?><?php echo e(asset('public/upload/page/'.$home_meta->page_image)); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('url'); ?><?php echo e(asset('/')); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('created_at'); ?><?php echo e($home_meta->created_at); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('updated_at'); ?><?php echo e($home_meta->updated_at); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('script_code'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style_code'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading3\lib\resources\views/site/home.blade.php ENDPATH**/ ?>