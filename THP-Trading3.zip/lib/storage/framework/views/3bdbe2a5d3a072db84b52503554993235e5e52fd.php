

<?php if(Session::has('success')): ?>
<div class="alert alert-success" role="alert" style="margin-top: 20px;">
  <h4 class="alert-heading"><i class="fas fa-bell"></i> Notice!</h4>
  <p><?php echo e(Session::get('success')); ?>.</p>
  
  
</div>
<?php endif; ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/error/success.blade.php ENDPATH**/ ?>