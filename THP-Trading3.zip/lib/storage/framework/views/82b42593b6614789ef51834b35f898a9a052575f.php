

	<div class="container">
		<nav aria-label="breadcrumb" class="" style="margin: 40px 0px;">
		  <ol class="breadcrumb" style="border-radius: 0;">
		  	
		    <li class="breadcrumb-item"><a href="<?php echo e(asset('')); ?>" class="text">Home</a></li>
		    

		    <?php if(isset($cate_detail)): ?>
		    	<li class="breadcrumb-item"><a href="<?php echo e(asset('/'.$cate_detail->cate_slug)); ?>" class="text-bold"><?php echo e($cate_detail->cate_name); ?></a></li>
		    <?php endif; ?>

		    <?php if(isset($cate_data)): ?>
		    	<li class="breadcrumb-item"><a href="<?php echo e(asset('/'.$cate_slug)); ?>" class="text-bold"><?php echo e($cate_data->cate_name); ?></a></li>
		    <?php endif; ?>

		    <?php if(isset($post_detail)): ?>
			<li class="breadcrumb-item active" aria-current="page" style="color: blue"><?php echo e($post_detail->post_title); ?></li>
			<?php endif; ?>
		  </ol>
		</nav>
	</div>
<?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading3\lib\resources\views/site/breadcrum.blade.php ENDPATH**/ ?>