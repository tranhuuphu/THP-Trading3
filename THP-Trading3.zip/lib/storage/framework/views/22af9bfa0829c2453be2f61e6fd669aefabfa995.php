

<?php $__env->startSection('content'); ?>

<div class="container">
	<nav aria-label="breadcrumb" style="margin: 30px 0;">
	  <ol class="breadcrumb" style="border-radius: 0;">
	    <li class="breadcrumb-item active" aria-current="page">Home</li>
	  </ol>
	</nav>
</div>
<!-- section -->
<div class="section" style="margin-top: 40px;">
	<!-- container -->
	<div class="container">
		<!-- row -->
		<div class="row">
			<div class="col-md-8">
				<h1>Vui lòng điền từ khóa khác phù hợp</h1>
				<form class="form-group has-search-right" method="get" action="<?php echo e(asset('search/')); ?>" style="border-radius: 0px;">
					<button type="submit" class="form-control-feedback"><span class="fa fa-search"></span></button>
					<input type="text" required="" name="q" placeholder="Search" type="text" class="form-control">
				</form>
			</div>
			<!-- aside -->
			<div class="col-md-4">
				<!-- ad -->
				<div class="aside-widget text-center">
					<a href="#" style="display: inline-block;margin: auto;">
						<img class="img-responsive" src="./img/ad-1.jpg" alt="">
					</a>
				</div>
				<!-- /ad -->

				
			</div>
			<!-- /aside -->
		</div>
		<!-- /row -->
	</div>
	<!-- /container -->
</div>
<!-- /section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\Xampp\htdocs\THP-Trading\lib\resources\views/error/401.blade.php ENDPATH**/ ?>